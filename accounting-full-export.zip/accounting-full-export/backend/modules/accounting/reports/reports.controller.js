// reports logic goes here
