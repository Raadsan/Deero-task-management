// shared logic goes here
